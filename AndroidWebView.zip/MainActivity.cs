﻿using System;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.Webkit;

namespace $safeprojectname$
{
    [Activity(Label = "PWSZ", MainLauncher = true, Icon = "@drawable/icon",Theme ="@android:style/Theme.NoTitleBar")]
    public class MainActivity : Activity
    {

        WebView webView;
        EditText txtUrl;
        Button btnLoad;
        Button button1;
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);
            webView = FindViewById<WebView>(Resource.Id.webView);
            txtUrl = FindViewById<EditText>(Resource.Id.txtUrl);
            btnLoad = FindViewById<Button>(Resource.Id.btnLoad);
            button1 = FindViewById<Button>(Resource.Id.button1);

            webView.SetWebViewClient(new ExtendWebViewClient());
           

            WebSettings webSettings = webView.Settings;
            webSettings.JavaScriptEnabled = true;

            btnLoad.Click += (s, e) => {
                
                    string address = txtUrl.Text;
                    txtUrl.Text = String.Format("http://www.pwsz.wloclawek.pl/galeria", address);
              

                webView.LoadUrl(txtUrl.Text);
            };
            button1.Click += (s, e) => {

                string address = txtUrl.Text;
                txtUrl.Text = String.Format("http://www.pwsz.wloclawek.pl/dyzury", address);


                webView.LoadUrl(txtUrl.Text);
            };


        }
    }

    internal class ExtendWebViewClient : WebViewClient
    {
        public override bool ShouldOverrideUrlLoading(WebView view, string url)
        {
            view.LoadUrl(url);
            return true;
        }
    }
}

